
def func_direct():
	print("yoda direct")

def func_imported():
	print("yoda imported")


if __name__ == '__main__':
	func_direct()
else:
	func_imported()