import yoda

print("anakin")